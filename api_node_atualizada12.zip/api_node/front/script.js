let button = document.getElementById('handleSubmit');

button.onclick = async function() {
    let name    = document.getElementsByClassName("name").value;
    let cpf     = document.getElementsByClassName("cpf").value;
    let senha   = document.getElementsByClassName("senha").value;
    let data    =  {name,cpf,senha}

    const response = await fetch('https://localhost:3000/api/store/task', {
        method: "POST",
        headers: {"Content-type": "application/json;charset=UTF-8"},
        body: JSON.stringify(data)
    });

    let content = await response.json();

    if(content.success) {
        alert("Sucesso")
    } else {
        alert('Não');
    }
    }

