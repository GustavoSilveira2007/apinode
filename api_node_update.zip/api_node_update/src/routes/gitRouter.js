const { Router } = require('express');
const router = Router();

const { storeGit } = require('../controller/gitController');

router.post('/store/git', storeGit);

module.exports = router;




