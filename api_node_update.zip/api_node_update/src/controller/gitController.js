const connection = require('../config/db')
const dotenv = require('dotenv').config();

async function storeGit(request, response) {
    const params = Array(
        request.body.cpf,
        request.body.destino,
        request.body.horariodescarga  
    )

    const query = "INSERT INTO programacao(cpf, destino, horariodescarga) VALUES(?, ?, ?)";
    
    connection.query(query, params, (err, results) => {
        if(results) {
            response.status(200).json({
                success: true,
                message: "Sucesso!",
                data: results
            })
        } else {
            response.status(400).json({
                success: false,
                message: "Erro!",
                sql: err,
            })
        }
    })
}

module.exports = (
    storeGit
)